<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="tela_compra.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="icon" href="img/QRPÃO.png" type="image/x-icon">
    <title>Menu de Padaria</title>
</head>

<body>

    <body onload="buscarProdutos()">
        <div class="top-bar"></div>
        <div class="container-fluid">
            <div class="row">
                <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block sidebar mt-1">
                    <div class="container-logo">
                        <div class="row">
                            <div class="col-md-12">
                                <img src="img/QRPÃO.png" alt="Imagem da Padaria" class="img-fluid" onclick="window.location.href = 'home/home.html'">
                            </div>
                        </div>
                    </div>
                </nav>


                <main class="col-md-9 ms-sm-auto col-lg-7 px-md-4">
                    <h1>Produtos da Padaria</h1>
                    <div class="container">
                        <!-- Barra de pesquisa -->
                        <div class="row">
                            <div class="col-md-6">
                                <form onsubmit="return buscarProdutos()">
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" placeholder="Digite o nome do produto" id="termo_pesquisa">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-primary" type="submit">Pesquisar</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="container" id="resultados_pesquisa" style="display: none;">
                        <!-- Os resultados da pesquisa serão exibidos aqui -->
                    </div>
                </main>
                <!-- Comanda à direita da tela -->
                <aside class="col-lg-3 d-none d-lg-block">
                    <div class="container" id="comanda-list" style="display: none;">
                        <h2>Comanda</h2>

                        <ul class="list-group">
                            <!-- Itens da comanda serão exibidos aqui -->
                        </ul>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="metodoPagamento" id="cartao" value="cartao" checked>
                            <label class="form-check-label" for="cartao">Cartão</label>
                        </div>

                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="metodoPagamento" id="dinheiro" value="dinheiro">
                            <label class="form-check-label" for="dinheiro">Dinheiro</label>
                        </div>

                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="metodoPagamento" id="pix-" value="pix">
                            <label class="form-check-label" for="pix">Pix</label>
                        </div>

                        <div id="total"></div>
                        <div class="btn-group btn-group-horizontal">
                            <button class="btn btn-danger" id="limpar-carrinho" onclick="limparCarrinho()" style="display: none">Limpar Carrinho</button>
                            <button class="btn btn-success" id="finalizar-compra" onclick="abrirModalPagamento()">Finalizar Compra</button>
                        </div>
                    </div>
                </aside>
            </div>
        </div>



        <!-- Modal para pagamento em dinheiro -->
        <div class="modal fade" id="modalPagamentoDinheiro" tabindex="-1" aria-labelledby="modalPagamentoDinheiroLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalPagamentoDinheiroLabel">Pagamento em Dinheiro</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <label for="valorPago">Valor Pago:</label>
                        <input type="text" class="form-control" id="valorPago">

                        <!-- Elemento para exibir o total da comanda -->
                        <div id="totalComandaModal"></div>

                        <!-- Elemento para exibir o total do troco -->
                        <div id="trocoModal"></div>
                    </div>
                    <div class="modal-footer">
                        <!-- Botão para calcular troco -->
                        <button type="button" class="btn btn-success" onclick="calcularTroco()">Calcular Troco</button>

                        <!-- Botão para finalizar compra -->
                        <button type="button" class="btn btn-primary" onclick="finalizarCompra()">Finalizar Pedido</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalPix" tabindex="-1" aria-labelledby="modalPixLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalPixLabel">Pagamento Pix</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- O elemento onde a imagem do QR code será exibida -->
                        <img id="qrcodePix" class="img-fluid" alt="QR Code Pix">

                    </div>
                    <div class="modal-footer">
                        <!-- Botão para finalizar compra -->
                        <button type="button" class="btn btn-primary" onclick="finalizarCompra()">Finalizar Pedido</button>
                    </div>
                </div>
            </div>
        </div>




        <script>
            var comandaList = document.getElementById('comanda-list');
            var totalElement = document.getElementById('total');
            var total = 0;
            var itensNaComanda = {};

            function atualizarBotoesComanda() {
                var botaoLimparCarrinho = document.getElementById('limpar-carrinho');
                var botaoFinalizarCompra = document.getElementById('finalizar-compra');

                if (total > 0) {
                    botaoLimparCarrinho.style.display = 'block';
                    botaoFinalizarCompra.style.display = 'block';
                } else {
                    botaoLimparCarrinho.style.display = 'none';
                    botaoFinalizarCompra.style.display = 'none';
                }
            }

            function adicionarItemComanda(nome, preco, quantidade) {
                console.log('adicionarItemComanda');
                if (!quantidade) {
                    quantidade = 1;
                }

                var comandaList = document.getElementById('comanda-list');
                var totalElement = document.getElementById('total');
                var botaoLimparCarrinho = document.getElementById('limpar-carrinho');
                var botaoFinalizarCompra = document.getElementById('finalizar-compra');

                // Verifica se a comanda já possui itens
                var comandaVazia = comandaList.querySelector('ul').childElementCount === 0;

                if (itensNaComanda[nome]) {
                    // Se já existe, apenas atualiza a quantidade
                    itensNaComanda[nome].quantidade += quantidade;
                } else {
                    // Se não existe, adiciona um novo item
                    var card = document.createElement('div');
                    card.className = 'card';
                    card.style = 'width: 18rem; margin-top: 10px;';

                    var cardBody = document.createElement('div');
                    cardBody.className = 'card-body';

                    cardBody.innerHTML = '<h5 class="card-title">' + nome + '</h5>' +
                        '<p class="card-text">Preço: R$ ' + preco + '</p>' +
                        '<p class="card-text">Quantidade: <span id="quantidade-' + nome + '">' + quantidade + '</span></p>';

                    card.appendChild(cardBody);
                    comandaList.querySelector('ul').appendChild(card);
                    itensNaComanda[nome] = {
                        preco: parseFloat(preco),
                        quantidade: quantidade
                    };

                    // Se a comanda estava vazia, exibe a comanda
                    if (comandaVazia) {
                        comandaList.style.display = 'block';
                        botaoLimparCarrinho.style.display = 'block';
                        botaoFinalizarCompra.style.display = 'block';
                    }
                }

                total += parseFloat(preco) * quantidade;
                totalElement.innerHTML = '<strong>Total: R$ ' + total.toFixed(2) + '</strong>';
                document.getElementById('quantidade-' + nome).innerText = itensNaComanda[nome].quantidade;
                atualizarBotoesComanda();
            }



            function adicionarQuantidade(idProduto, nome, preco) {
                console.log('adicionarQuantidade');
                var quantidadeInput = document.getElementById('quantidade_' + idProduto);
                var quantidade = parseInt(quantidadeInput.value);

                adicionarItemComanda(nome, preco, quantidade);
            }

            function buscarProdutos() {
                var termoPesquisa = document.getElementById('termo_pesquisa').value;
                var resultadosPesquisa = document.getElementById('resultados_pesquisa');

                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4) {
                        if (xhr.status == 200) {
                            if (xhr.responseText.trim() !== "") {
                                resultadosPesquisa.innerHTML = xhr.responseText;
                                resultadosPesquisa.style.display = 'block'; // Exibir a div quando houver resultados
                            } else {
                                resultadosPesquisa.style.display = 'none'; // Esconder a div quando não houver resultados
                            }
                        }
                    }
                };

                xhr.open('GET', 'buscar_produtos.php?termo_pesquisa=' + termoPesquisa, true);
                xhr.send();
                return false; // Impede o envio do formulário tradicional
            }

            function limparCarrinho() {
                var comandaListUl = comandaList.querySelector('ul');

                while (comandaListUl.firstChild) {
                    comandaListUl.removeChild(comandaListUl.firstChild);
                }

                comandaList.style.display = 'none';

                itensNaComanda = {};
                total = 0;
                totalElement.innerHTML = '<strong>Total: R$ ' + total.toFixed(2) + '</strong>';
                atualizarBotoesComanda();
            }

            function finalizarCompra() {
                // Adicione aqui a lógica para finalizar a compra, se necessário
                alert('Compra finalizada com sucesso!');
                location.reload(true);
            }




            function abrirModalPagamento() {
                var metodoPagamento = document.querySelector('input[name="metodoPagamento"]:checked').value;

                if (metodoPagamento === 'dinheiro') {
                    // Lógica para pagamento em dinheiro
                    document.getElementById('totalComandaModal').innerHTML = '<p>Total da Comanda: R$ ' + total.toFixed(2) + '</p>';
                    var modalPagamentoDinheiro = new bootstrap.Modal(document.getElementById('modalPagamentoDinheiro'));
                    modalPagamentoDinheiro.show();
                } else if (metodoPagamento === 'pix') {
                    // Lógica para pagamento Pix
                    // Supondo que você tenha a URL da imagem do QR code no banco de dados
                    var urlQrCode = 'img/qrcode.jpg';

                    // Exiba a imagem do QR code
                    document.getElementById('qrcodePix').src = urlQrCode;

                    // Exiba o modal Pix
                    var modalPix = new bootstrap.Modal(document.getElementById('modalPix'));
                    modalPix.show();
                } else {
                    // Lógica para pagamento com cartão
                    alert('Pagamento com cartão processado com sucesso!');
                    location.reload(true);
                }
            }




            function processarPagamentoDinheiroModal() {
                // Obtenha o valor pago do campo de input no modal
                var valorPago = parseFloat(document.getElementById('valorPago').value);

                // Verifique se o valor pago é válido
                if (isNaN(valorPago) || valorPago <= 0) {
                    alert('Insira um valor válido para pagamento.');
                    return;
                }

                // Obtenha o total da comanda em centavos
                var totalComandaCentavos = Math.round(total * 100);

                // Converta o valor pago para centavos
                var valorPagoCentavos = Math.round(valorPago * 100);

                // Calcule o troco em centavos
                var trocoCentavos = valorPagoCentavos - totalComandaCentavos;

                if (trocoCentavos >= 0) {
                    // Converta o troco de volta para reais
                    var trocoReais = trocoCentavos / 100;

                    // O pagamento é suficiente, exiba o troco
                    alert('Pagamento em dinheiro recebido com sucesso!\nTroco: R$ ' + trocoReais.toFixed(2));
                    location.reload(true);
                } else {
                    // Valor insuficiente, exiba uma mensagem
                    alert('Valor insuficiente. Por favor, insira um valor válido.');
                }
            }

            function calcularTroco() {
                // Obtenha o valor pago do campo de input no modal
                var valorPago = parseFloat(document.getElementById('valorPago').value);

                // Verifique se o valor pago é válido
                if (isNaN(valorPago) || valorPago <= 0) {
                    alert('Insira um valor válido para pagamento.');
                    return;
                }

                // Obtenha o total da comanda em centavos
                var totalComandaCentavos = Math.round(total * 100);

                // Converta o valor pago para centavos
                var valorPagoCentavos = Math.round(valorPago * 100);

                // Calcule o troco em centavos
                var trocoCentavos = valorPagoCentavos - totalComandaCentavos;

                // Converta o troco de volta para reais
                var trocoReais = trocoCentavos / 100;

                // Atualize os elementos para exibir o resultado
                document.getElementById('totalComandaModal').innerHTML = '<p>Total da Comanda: R$ ' + total.toFixed(2) + '</p>';
                document.getElementById('trocoModal').innerHTML = '<p>Troco: R$ ' + trocoReais.toFixed(2) + '</p>';
            }
        </script>

        <script src="https://cdn.rawgit.com/davidshimjs/qrcodejs/gh-pages/qrcode.min.js"></script>
    </body>

</html>