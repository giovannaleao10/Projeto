<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cpf = $_POST["cpf"];
    $senha = $_POST["senha"];
    
    // Conecte ao banco de dados (substitua as informações de conexão)
    $conn = new mysqli("localhost", "root", "", "comanda");
    
    if ($conn->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conn->connect_error);
    }
    
    // Consulta SQL para verificar as credenciais
    $sql = "SELECT * FROM funcionarios WHERE cpf = '$cpf' AND senha = '$senha'";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        // Login bem-sucedido
        echo "<script>window.location.href = 'tela_compra.php';</script>";
    } else {
        // Login falhou
        echo "Credenciais inválidas. Tente novamente.";
    }
    
    $conn->close();
}
