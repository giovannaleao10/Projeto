<?php
// Conexão com o banco de dados
$conexao = new mysqli("localhost", "root", "", "comanda");
if ($conexao->connect_error) {
    die("Erro na conexão: " . $conexao->connect_error);
}

// Defina um valor padrão para $termo_pesquisa
$termo_pesquisa = '';

// Verifique se o termo de pesquisa está definido
if (isset($_GET['termo_pesquisa'])) {
    $termo_pesquisa = $_GET['termo_pesquisa'];

    // Consulta SQL para buscar produtos com base no termo de pesquisa
    $sql = "SELECT * FROM produtos WHERE nome LIKE '%$termo_pesquisa%'";
} else {
    // Consulta SQL para buscar todos os produtos quando nenhum termo de pesquisa é especificado
    $sql = "SELECT * FROM produtos";
}

$result = $conexao->query($sql);

// Exibir os resultados da pesquisa ou todos os produtos
while ($row = $result->fetch_assoc()) {
    echo '<div class="card mb-4 shadow-sm">';
    echo '    <div class="d-flex">';
    echo '        <img src="' . $row['caminho'] . '" alt="' . $row['nome'] . '" class="card-img-top">';
    echo '        <div class="card-body d-flex flex-column">';
    echo '            <div class="d-flex justify-content-between align-items-center">';
    echo '                <h5 class="card-title">' . $row['nome'] . '</h5>';
    echo '                <span class="price">$' . number_format($row['preco'], 2) . '</span>';
    echo '            </div>';
    echo '            <p class="card-text">' . $row['descricao'] . '</p>';
    echo '            <div class="d-flex justify-content-between align-items-center">';
    echo '                <span class="input-group">';
    echo '                    <input type="number" class="form-control" value="1" min="1" id="quantidade_' . $row['idprodutos'] . '">';
    echo '                    <button onclick="adicionarQuantidade(' . $row['idprodutos'] . ', \'' . $row['nome'] . '\', ' . $row['preco'] . ')" class="btn btn-sm btn-outline-primary">Adicionar</button>';
    echo '                </span>';
    echo '            </div>';
    echo '        </div>';
    echo '    </div>';
    echo '</div>';
}

$conexao->close();
?>
