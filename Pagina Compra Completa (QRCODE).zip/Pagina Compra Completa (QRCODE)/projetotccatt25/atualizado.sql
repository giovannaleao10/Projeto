DELETE FROM produtos WHERE idprodutos BETWEEN 6 AND 11;
create database comanda;
drop database comanda;
SET SQL_SAFE_UPDATES = 1;

INSERT INTO produtos (nome, descricao, preco, caminho)
VALUES ('Pão', 'Pão Francês', 0.50, 'img/1.png');

-- Inserir registro para "Pudim"
INSERT INTO produtos (nome, descricao, preco, caminho)
VALUES ('Pudim', 'Sobremesa de Pudim Cremoso', 4.99, 'img/3.png');

-- Inserir registro para "Café"
INSERT INTO produtos (nome, descricao, preco, caminho)
VALUES ('Café', 'Café Aromático', 2.49, 'img/2.png');

-- Inserir registro para "Pão de Queijo"
INSERT INTO produtos (nome, descricao, preco, caminho)
VALUES ('Pão de Queijo', 'Delicioso Pão de Queijo', 1.99, 'img/4.png');

-- Inserir registro para "Brownie"
INSERT INTO produtos (nome, descricao, preco, caminho)
VALUES ('Brownie', 'Brownie de Chocolate', 3.49, 'img/5.png');

select * from produtos;




CREATE TABLE comanda (
  idcomanda INT UNSIGNED NOT NULL AUTO_INCREMENT,
  cod_qr_code NUMERIC NULL,
  valor_total FLOAT NULL,
  abertura_inicial TIME NULL,
  abertura_fim TIME NULL,
  PRIMARY KEY(idcomanda)
);

CREATE TABLE funcionarios (
  idfuncionarios INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(255) NULL,
  cpf VARCHAR(11) NULL,
  senha VARCHAR(100),
  PRIMARY KEY(idfuncionarios)
);

CREATE TABLE produtos (
  idprodutos INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nome VARCHAR(255) NULL,
  descricao VARCHAR(255) NULL,
  preco FLOAT NULL,
  caminho VARCHAR(255),
  PRIMARY KEY(idprodutos)
);


CREATE TABLE comanda_has_produtos (
  idcomanda_has_produtos INT UNSIGNED NOT NULL AUTO_INCREMENT,
  comanda_idcomanda INT UNSIGNED NOT NULL,
  produtos_idprodutos INT UNSIGNED NOT NULL,
  PRIMARY KEY(idcomanda_has_produtos),
  INDEX comanda_has_produtos_FKIndex1(comanda_idcomanda),
  INDEX comanda_has_produtos_FKIndex2(produtos_idprodutos),
  FOREIGN KEY(comanda_idcomanda) REFERENCES comanda(idcomanda),
  FOREIGN KEY(produtos_idprodutos) REFERENCES produtos(idprodutos)
);

CREATE TABLE venda (
  idvenda INT UNSIGNED NOT NULL AUTO_INCREMENT,
  funcionarios_idfuncionarios INT UNSIGNED NOT NULL,
  comanda_idcomanda INT UNSIGNED NOT NULL,
  venda_inicio TIME NULL,
  venda_fim TIME NULL,
  PRIMARY KEY(idvenda),
  INDEX venda_FKIndex1(comanda_idcomanda),
  INDEX venda_FKIndex2(funcionarios_idfuncionarios),
  FOREIGN KEY(comanda_idcomanda) REFERENCES comanda(idcomanda),
  FOREIGN KEY(funcionarios_idfuncionarios) REFERENCES funcionarios(idfuncionarios)
);

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `fone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO funcionarios (nome, cpf) VALUES ('João Silva', '12345678910');
INSERT INTO produtos (nome, descricao, preco, caminho) VALUES ('Camiseta', 'Camiseta de algodão', 29.99, 'img/camiseta.png');
INSERT INTO produtos (nome, descricao, preco, caminho) VALUES ('Tenis', 'Tenis Branco', 299.99, 'img/tenis.png');
INSERT INTO comanda (cod_qr_code, valor_total, abertura_inicial, abertura_fim)
VALUES ('123456', 0.00, '09:00:00', NULL);
INSERT INTO comanda_has_produtos (comanda_idcomanda, produtos_idprodutos)
VALUES (1, 1); -- Inserir na comanda 1 o produto 1
INSERT INTO venda (funcionarios_idfuncionarios, comanda_idcomanda, venda_inicio)
VALUES (1, 1, '10:30:00');



SELECT * FROM funcionarios;
SELECT nome, cpf FROM funcionarios;
SELECT nome, cpf FROM funcionarios;
SELECT nome, preco FROM produtos;
SELECT * FROM venda;
SELECT p.nome
FROM produtos p
INNER JOIN comanda_has_produtos cp ON p.idprodutos = cp.produtos_idprodutos
WHERE cp.comanda_idcomanda = 1;
SELECT *
FROM venda
WHERE funcionarios_idfuncionarios = 1;
SELECT
  c.idcomanda,
  COUNT(v.idvenda) AS total_vendas,
  SUM(c.valor_total) AS valor_total_comanda
FROM
  comanda c
INNER JOIN
  venda v ON c.idcomanda = v.comanda_idcomanda
GROUP BY
  c.idcomanda;